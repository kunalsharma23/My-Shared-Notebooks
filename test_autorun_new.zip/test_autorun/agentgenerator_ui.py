import os
import streamlit as st
import pandas as pd
from io import StringIO
import pycaret
from pycaret.classification import *

# Set the fixed directory for YAML files
# BASE_DIR = os.getcwd()  # Current working directory
# GENERATED_DIR = os.path.join(BASE_DIR, "yaml")
# os.makedirs(GENERATED_DIR, exist_ok=True)

def streamlit_ui():
    """UI for generating YAML files."""
    st.header("Generate Agent")
    st.markdown("Use this tool to generate agents, tasks, and execute workflows.")

    # Form for user inputs
    with st.form("use_case_form"):
        use_case = st.text_area("Enter the Use Case Description", "")
        input_path = st.text_input("Enter the input path (if applicable)", "")
        # directory = st.text_input("Enter the directory (if applicable)", "")
        query = st.text_input("Enter the query/topic (if applicable)", "")
        # output_path = st.text_input("Enter the output path (if applicable)", "")
        # db_path = st.text_input("Enter the database URI (e.g., postgresql://, mysql://) (if applicable): ", "")
        # table_name = st.text_input("Enter the table name (if applicable): ", "")
        submitted = st.form_submit_button("Generate and Run Agent")

    if submitted:
        if not use_case.strip():
            st.error("Use Case Description is required ")
            return

        dynamic_inputs = {
            "input_path": input_path.strip(),
            "query": query.strip()

            # "db_path": db_path.strip(),
            # "table_name":  table_name.strip()
        }

        # Interpret the use case
        st.write("### Step 1: Interpreting Use Case")
        with st.spinner("Interpreting the use case..."):
            master_agent = MasterAgent()
            try:
                yaml_config = interpret_use_case(use_case,dynamic_inputs)
                cleaned_config = str(yaml_config).strip("```json\n").strip("\n```").strip()
                st.success("Use Case interpreted successfully.")
                st.code(cleaned_config, language="yaml")
            except Exception as e:
                st.error(f"Error interpreting use case: {e}")
                return

        # Generate YAML files
        st.write("### Step 2: Generating YAML Files")
        use_case_name = get_shorter_name(use_case)
        with st.spinner("Generating YAML files..."):
            try:


                result = master_agent.generate_yaml_files(cleaned_config, use_case_name)
                print(result)
                st.success("YAML files generated successfully.")
                agent_file = result+"_agent.yaml"
                task_file = result+"_task.yaml"
                flow_file = result+".json"

                st.write("#### Generated Files:")
                st.write(f"Agent File: `{agent_file}`")
                # st.write(f"Task File: `{task_file}`")
                # st.write(f"Flow Config JSON: `{flow_file}`")

                # # Provide download links
                # with open(agent_file, "rb") as file:
                #     st.download_button("Download Agent YAML", file, file_name=f"{use_case_name}_agent.yaml")
                # with open(task_file, "rb") as file:
                #     st.download_button("Download Task YAML", file, file_name=f"{use_case_name}_task.yaml")
                # with open(flow_file, "rb") as file:
                #     st.download_button("Download Flow Config JSON", file, file_name=f"{use_case_name}.json")

            except Exception as e:
                st.error(f"Error generating YAML files: {e}")
                return

        # Run the crew
        st.write("### Step 3: Running Agent")
        with st.spinner("Running the Agent..."):
            try:
                result = run_crew(
                    flow_file=flow_file,
                    inputs=dynamic_inputs,
                    agents_config=agent_file,
                    tasks_config=task_file
                )
                st.success("Agent run successfully. Here is the result:")
                st.write(result)
            except Exception as e:
                st.error(f"Error running Agent: {e}")

def run_grouped_yamls_ui():
    """UI for running grouped YAML configurations."""
    def group_files_by_name(directory):
        grouped_files = {}
        for file in os.listdir(directory):
            if file.endswith(("_agent.yaml", "_task.yaml", ".json")):
                base_name = file.split("_agent.yaml")[0] if "_agent.yaml" in file else \
                            file.split("_task.yaml")[0] if "_task.yaml" in file else \
                            file.split(".json")[0]
                if base_name not in grouped_files:
                    grouped_files[base_name] = {"agent": None, "task": None, "flow": None}
                if file.endswith("_agent.yaml"):
                    grouped_files[base_name]["agent"] = os.path.join(directory, file)
                elif file.endswith("_task.yaml"):
                    grouped_files[base_name]["task"] = os.path.join(directory, file)
                elif file.endswith(".json"):
                    grouped_files[base_name]["flow"] = os.path.join(directory, file)
        return grouped_files

    st.header("Run Agent")
    # st.markdown("Select a pre-generated workflow to execute.")

    grouped_files = group_files_by_name("src/prior_auth_agent_flow/yaml")

    if not grouped_files:
        st.warning("No YAML or JSON files found in the directory. Please generate them first.")
        return

    # Allow user to select a group
    use_case_names = list(grouped_files.keys())
    selected_group = st.selectbox("Select Use Case", use_case_names)

    if selected_group:
        # st.write("### Selected Files:")
        files = grouped_files[selected_group]

        # st.write("### Provide Dynamic Inputs (if applicable)")
        input_path = st.text_input("Input Path", "")
        # directory = st.text_input("Directory", "")
        query = st.text_input("Query/Topic", "")

        dynamic_inputs = {
            "input_path": input_path.strip(),
            "query": query.strip()
        }

        if st.button("Run Agent"):
            st.write("### Running Agent")
            with st.spinner("Running the agent..."):
                try:
                    if not files['agent'] or not files['task'] or not files['flow']:
                        st.error("One or more required files are missing in the selected group.")
                        return

                    result = run_crew(
                        flow_file=files['flow'],
                        inputs=dynamic_inputs,
                        agents_config=files['agent'],
                        tasks_config=files['task']
                    )
                    st.success("Agent run successfully. Here is the result:")
                    st.write(result)
                except Exception as e:
                    st.error(f"Error running Agent: {e}")

############################################################################################################
def model_prediction():
    """Model training and prediction."""
    st.header("Model Prediction")
    st.markdown("Use this tool to build your own customize traditional models, Classification, Regression and Time-Series Forecasting.")

    # Form for user inputs
    with st.form("model_building_form"):
        use_case = st.text_area("Enter the Use Case Description", "")
        include_vars = st.text_input("Enter the features that has to be in modelling (if applicable)", "")
        exclude_vars = st.text_input("Enter the features that needs to be excluded from modelling (if applicable)", "")
        uploaded_file_train = st.file_uploader('Choose a file for training..')
        uploaded_file_test = st.file_uploader('Choose a file for Prediction..')
        submitted = st.form_submit_button("Start Training")

    if submitted:
        if uploaded_file_train == None or uploaded_file_test == None:
            st.error("Warning..! Data needs to be uploaded ")
            return

        # Interpret the use case
        st.write("### Step 1: Load the Data")
        with st.spinner("Data Loading in progress..."):
            # master_agent = MasterAgent()
            try:
                if uploaded_file_train is not None:
                    df_train = pd.read_csv(uploaded_file_train)
                if uploaded_file_test is not None:
                    df_test = pd.read_csv(uploaded_file_test)
                # yaml_config = interpret_use_case(use_case,dynamic_inputs)
                # cleaned_config = str(yaml_config).strip("```json\n").strip("\n```").strip()
                st.success("Data Loaded successfully.")
                # st.code(cleaned_config, language="yaml")
            except Exception as e:
                st.error(f"Error Loading the data..: {e}")
                return

        # Generate YAML files
        st.write("### Step 2: Data Preprocess")
        # use_case_name = get_shorter_name(use_case)
        with st.spinner("Data Preprocessing..."):
            try:
                # import pycaret classification and init setup
                from pycaret.classification import setup
                s = setup(df_train, target = 'Class variable', session_id = 123)
                
                # import ClassificationExperiment and init the class
                from pycaret.classification import ClassificationExperiment
                exp = ClassificationExperiment()
                # init setup on exp
                exp.setup(df_train, target = 'Class variable', session_id = 123)

                # result = master_agent.generate_yaml_files(cleaned_config, use_case_name)
                # print(result)
                st.success("Data Preprocessing completed successfully.")

                # st.write("#### Generated Files:")
                # st.write(f"Agent File: `{agent_file}`")
                # st.write(f"Task File: `{task_file}`")
                # st.write(f"Flow Config JSON: `{flow_file}`")

                # # Provide download links
                # with open(agent_file, "rb") as file:
                #     st.download_button("Download Agent YAML", file, file_name=f"{use_case_name}_agent.yaml")
                # with open(task_file, "rb") as file:
                #     st.download_button("Download Task YAML", file, file_name=f"{use_case_name}_task.yaml")
                # with open(flow_file, "rb") as file:
                #     st.download_button("Download Flow Config JSON", file, file_name=f"{use_case_name}.json")

            except Exception as e:
                st.error(f"Error preprocessing Data..: {e}")
                return

        # Model training
        st.write("### Step 3: Model Training")
        with st.spinner("Model Training in Progress..."):
            try:
                # compare baseline models
                best = compare_models()
                # compare models using OOP
                exp.compare_models()
                # plot confusion matrix
                plot_model(best, plot = 'confusion_matrix')
                # plot AUC
                plot_model(best, plot = 'auc')
                # plot feature importance
                plot_model(best, plot = 'feature')
                evaluate_model(best)
                # predict on test set
                holdout_pred = predict_model(best)
                
                # show predictions df
                # holdout_pred.head()
                st.success("Model Build successfully!")
                # st.write(result)
            except Exception as e:
                st.error(f"Error building the models: {e}")

        # Model training
        st.write("### Step 4: Model Prediction")
        with st.spinner("Model Prediction in Progress..."):
            try:
                # copy data and drop Class variable
                
                new_data = df_test.copy()
                new_data.drop('Class variable', axis=1, inplace=True)
                # new_data.head()
                
                # predict model on new_data
                predictions = predict_model(best, data = new_data)
                # predictions.head(10)

                st.success("Prediction done successfully!. Here is the result")
                st.write(predictions)
                st.download_button("Download File", predictions.to_csv(), file_name='predictions.csv')

            except Exception as e:
                st.error(f"Error in predictions: {e}")

############################################################################################################

def main():
    st.sidebar.title("Menu:")
    st.image("src/prior_auth_agent_flow/img/AttinioLogo.svg", caption="Turning Any Company Into an AI Company")
    st.logo("src/prior_auth_agent_flow/img/attinio-fav-icon-new.png", size="large")
    menu = st.sidebar.radio(
        "Select a Page",
        ["Generate Agent", "Run Existing Agent",'Model Prediction']
    )

    if menu == "Generate Agent":
        # streamlit_ui()
        pass
    elif menu == "Run Existing Agent":
        # run_grouped_yamls_ui()
        pass
    elif menu == 'Model Prediction':
        model_prediction()

if __name__ == "__main__":
    main()
